# Morley

Morphometry of germinated plants in Python

Morley is open-sourse software for plants morphometry: measuring sprouts, roots length.
